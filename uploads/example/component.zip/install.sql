-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Авг 16 2016 г., 16:28
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `newbase`
--

-- --------------------------------------------------------

--
-- Структура таблицы `com_loads_item`
--

CREATE TABLE IF NOT EXISTS `com_loads_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `shortcut` varchar(32) NOT NULL,
  `name` text NOT NULL,
  `turned_on` int(11) NOT NULL,
  `image` int(11) NOT NULL,
  `downloaded` int(11) NOT NULL,
  `author` int(11) NOT NULL,
  `description` text NOT NULL,
  `date` datetime NOT NULL,
  `file` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `com_loads_item`
--

INSERT INTO `com_loads_item` (`id`, `cat_id`, `shortcut`, `name`, `turned_on`, `image`, `downloaded`, `author`, `description`, `date`, `file`) VALUES
(1, 2, 'loads_component', 'Файлдар компоненти', 1, 0, 0, 1, 'Ураа!!!!!!!!!!!', '2015-07-15 00:00:00', 'component_files'),
(2, 3, 'bajyt.html', 'bajyt', 1, 0, 0, 1, '<p>gf mh fg</p>\r\n', '2015-06-15 12:36:17', 'bajyt'),
(3, 3, 'Baha.html', 'Баха', 1, 0, 1, 1, '<p>ИТс ме</p>\r\n', '2015-06-15 12:45:10', 'Baha'),
(4, 3, '1_o_daa.html', 'о даа', 1, 0, 0, 1, '<p>о даа</p>\r\n', '2015-06-15 13:08:11', 'o_daa'),
(5, 3, '1_123.html', '123', 1, 1, 0, 1, '<p>123</p>\r\n', '2015-06-15 13:11:39', '123'),
(6, 3, '6_mjnhcvnb_bb_nv.html', 'mjnhcvnb bb nv', 1, 6, 0, 1, '<p>&nbsp;hg jhnbvnb</p>\r\n', '2015-06-15 13:18:41', 'mjnhcvnb_bb_nv'),
(7, 2, '7_12345648798.html', '12345648798', 1, 7, 1, 1, '<p>nbjgjhb hbjhbjh</p>\r\n', '2015-06-15 13:26:01', '12345648798.rar'),
(8, 1, '8_bakyt.html', 'bakyt', 1, 8, 0, 1, '<p>bakyt</p>\r\n', '2015-06-15 23:10:02', 'bakytpdf'),
(9, 2, '9_You.html', 'You', 1, 9, 0, 1, '<p>Me</p>\r\n', '2015-06-15 23:18:58', 'Youpdf'),
(10, 2, '10_Alhamdulillah.html', 'Alhamdulillah', 1, 0, 6, 1, '<p>Chok shukur</p>\r\n', '2015-06-15 23:23:22', 'Alhamdulillah.zip'),
(11, 3, '11_Eheeeheeee.html', 'Eheeeheeee', 1, 0, 1, 1, '<p>daaa</p>\r\n', '2015-06-26 18:51:37', 'Eheeeheeee.docx');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
