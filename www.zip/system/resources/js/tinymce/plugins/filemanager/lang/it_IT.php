<?php
define('lang_Select','Seleziona');
define('lang_Erase','Cancella');
define('lang_Open','Apri');
define('lang_Confirm_del','Sei sicuro di volere cancellare questo file?');
define('lang_All','Tutti');
define('lang_Files','Files');
define('lang_Images','Immagini');
define('lang_Archives','Archivi');
define('lang_Error_Upload','Il file caricato supera i limiti imposti.');
define('lang_Error_extension','Il tipo del file caricato non è permesso.');
define('lang_Upload_file','Carica');
define('lang_Filter','Filtro');
define('lang_Videos','Video');
define('lang_Music','Musica');
define('lang_New_Folder','Nuova Cartella');
define('lang_Folder_Created','Cartella creata correttamente');
define('lang_Existing_Folder','Cartella già esistente');
define('lang_Confirm_Folder_del','Sei sicuro di voler cancellare la cartella e tutti i file in essa contenuti?');
define('lang_Return_Files_List','Ritorna alla lista dei file');
define('lang_Preview','Anteprima');
define('lang_Download','Download');
define('lang_Insert_Folder_Name','Inserisci il nome della cartella:');
define('lang_Root','base');
?>
