<?php
define('lang_Select','Ausw&auml;hlen');
define('lang_Erase','L&ouml;schen');
define('lang_Open','&Ouml;ffnen');
define('lang_Confirm_del','Wollen Sie wirklich diese Datei l&ouml;schen?');
define('lang_All','Alle');
define('lang_Files','Dateien');
define('lang_Images','Bilder');
define('lang_Archives','Archive');
define('lang_Error_Upload','Dateigr&ouml;&szlig;e &uuml;berschritten.');
define('lang_Error_extension','Dateityp nicht erlaubt.');
define('lang_Upload_file','Datei hochladen');
define('lang_Filter','Filter');
define('lang_Videos','Videos');
define('lang_Music','Musik');
define('lang_New_Folder','Neuer Ordner');
define('lang_Folder_Created','Ordner erfolgreich erstellt');
define('lang_Existing_Folder','Ordner existiert bereichts');
define('lang_Confirm_Folder_del','Sind Sie sich, dass Sie diesen Ordner mit allen enthaltenen Dateien l&ouml;schen m&ouml;chten?');
define('lang_Return_Files_List','Zur&uuml;ck zur Dateiliste');
define('lang_Preview','Vorschau');
define('lang_Download','Download');
define('lang_Insert_Folder_Name','Ordnername eingeben:');
define('lang_Root','Basis');
?>
